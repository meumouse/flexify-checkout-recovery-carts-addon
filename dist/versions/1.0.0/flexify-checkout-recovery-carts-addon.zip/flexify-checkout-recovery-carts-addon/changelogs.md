Versão 1.0.0 (06/03/2025)
* Versão inicial