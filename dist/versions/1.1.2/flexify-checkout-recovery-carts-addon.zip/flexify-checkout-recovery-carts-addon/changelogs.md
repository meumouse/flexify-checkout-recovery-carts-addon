Versão 1.1.2 (24/03/2025)
* Correção de bugs
    Criação do carrinho apenas se usuário tem produtos no carrinho
* Otimizações

Versão 1.1.0 (24/03/2025)
* Correção de bugs
* Otimizações
* Recurso adicionado: Intervalo de requisições

Versão 1.0.2 (10/03/2025)
* Recurso adicionado: Rotina de verificação de atualizações

Versão 1.0.1 (10/03/2025)
* Correção de bugs
* Otimizações
* Recurso adicionado: Ativar coleta de localização através do IP

Versão 1.0.0 (06/03/2025)
* Versão inicial