Versão 1.0.1 (10/03/2025)
* Correção de bugs
* Otimizações
* Recurso adicionado: Ativar coleta de localização através do IP

Versão 1.0.0 (06/03/2025)
* Versão inicial